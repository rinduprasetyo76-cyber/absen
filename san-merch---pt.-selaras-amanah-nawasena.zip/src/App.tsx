import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Camera, 
  Clock, 
  User as UserIcon, 
  LogOut, 
  History, 
  CheckCircle2, 
  Store, 
  ChevronRight,
  Loader2,
  AlertCircle,
  Home,
  Briefcase,
  FileText,
  Plus,
  Image as ImageIcon,
  Send
} from 'lucide-react';
import { User, Attendance, Visit, Report } from './types';

const API_BASE = '/api';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'reports' | 'profile'>('home');
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [attendanceHistory, setAttendanceHistory] = useState<Attendance[]>([]);
  const [visitHistory, setVisitHistory] = useState<Visit[]>([]);
  const [reportHistory, setReportHistory] = useState<Report[]>([]);
  const [activeVisit, setActiveVisit] = useState<Visit | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraPurpose, setCameraPurpose] = useState<'attendance' | 'report_before' | 'report_after' | 'report_promo' | 'report_extra'>('attendance');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [reportPhotos, setReportPhotos] = useState<{
    before: string | null;
    after: string | null;
    promo: string | null;
    extra: string | null;
  }>({
    before: null,
    after: null,
    promo: null,
    extra: null
  });

  // Login State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Report State
  const [reportStore, setReportStore] = useState('');
  const [reportDesc, setReportDesc] = useState('');

  useEffect(() => {
    if (user) {
      fetchHistory();
      requestLocation();
    }
  }, [user]);

  const requestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => setError("Gagal mendapatkan lokasi. Pastikan GPS aktif.")
      );
    }
  };

  const fetchHistory = async () => {
    if (!user) return;
    try {
      const [attRes, visitRes, reportRes] = await Promise.all([
        fetch(`${API_BASE}/attendance/${user.id}`),
        fetch(`${API_BASE}/visits/${user.id}`),
        fetch(`${API_BASE}/reports/${user.id}`)
      ]);
      const attData = await attRes.json();
      const visitData = await visitRes.json();
      const reportData = await reportRes.json();
      setAttendanceHistory(attData);
      setVisitHistory(visitData);
      setReportHistory(reportData);
      
      const ongoing = visitData.find((v: Visit) => !v.end_time);
      if (ongoing) setActiveVisit(ongoing);
    } catch (e) {
      console.error("Failed to fetch history", e);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API_BASE}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
      } else {
        setError(data.message);
      }
    } catch (e) {
      setError("Terjadi kesalahan koneksi.");
    } finally {
      setLoading(false);
    }
  };

  const startCamera = async (purpose: 'attendance' | 'report_before' | 'report_after' | 'report_promo' | 'report_extra') => {
    setCameraPurpose(purpose);
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: purpose === 'attendance' ? 'user' : 'environment' } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError("Gagal mengakses kamera.");
      setShowCamera(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        
        if (cameraPurpose === 'attendance') {
          setCapturedPhoto(dataUrl);
        } else if (cameraPurpose === 'report_before') {
          setReportPhotos(prev => ({ ...prev, before: dataUrl }));
        } else if (cameraPurpose === 'report_after') {
          setReportPhotos(prev => ({ ...prev, after: dataUrl }));
        } else if (cameraPurpose === 'report_promo') {
          setReportPhotos(prev => ({ ...prev, promo: dataUrl }));
        } else if (cameraPurpose === 'report_extra') {
          setReportPhotos(prev => ({ ...prev, extra: dataUrl }));
        }
        
        // Stop stream
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        setShowCamera(false);
      }
    }
  };

  const handleAttendance = async (type: 'check-in' | 'check-out') => {
    if (!location) {
      requestLocation();
      setError("Menunggu lokasi...");
      return;
    }
    if (!capturedPhoto) {
      setError("Ambil foto terlebih dahulu.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/attendance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          type,
          latitude: location.lat,
          longitude: location.lng,
          photo_url: capturedPhoto
        })
      });
      if (res.ok) {
        setCapturedPhoto(null);
        fetchHistory();
      }
    } catch (e) {
      setError("Gagal mengirim absensi.");
    } finally {
      setLoading(false);
    }
  };

  const handleStartVisit = async (storeName: string) => {
    if (!location) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/visits/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          store_name: storeName,
          latitude: location.lat,
          longitude: location.lng
        })
      });
      if (res.ok) {
        fetchHistory();
      }
    } catch (e) {
      setError("Gagal memulai kunjungan.");
    } finally {
      setLoading(false);
    }
  };

  const handleEndVisit = async (notes: string) => {
    if (!activeVisit) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/visits/end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          visit_id: activeVisit.id,
          notes
        })
      });
      if (res.ok) {
        setActiveVisit(null);
        fetchHistory();
      }
    } catch (e) {
      setError("Gagal mengakhiri kunjungan.");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateReport = async () => {
    if (!reportPhotos.before || !reportPhotos.after || !reportStore || !reportDesc) {
      setError("Lengkapi data laporan (Minimal Foto Before & After).");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/reports`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          store_name: reportStore,
          photo_before: reportPhotos.before,
          photo_after: reportPhotos.after,
          photo_promo: reportPhotos.promo,
          photo_extra: reportPhotos.extra,
          description: reportDesc
        })
      });
      if (res.ok) {
        setReportPhotos({ before: null, after: null, promo: null, extra: null });
        setReportStore('');
        setReportDesc('');
        fetchHistory();
        setActiveTab('reports');
      }
    } catch (e) {
      setError("Gagal mengirim laporan.");
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-white rounded-3xl shadow-xl p-8 border border-slate-100"
        >
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-emerald-500 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-lg shadow-emerald-200">
              <Briefcase className="text-white w-10 h-10" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">SAN Merchandiser</h1>
            <p className="text-slate-500 text-sm mt-1">Pt. Selaras Amanah Nawasena</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Username</label>
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
                placeholder="Masukkan username"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
                placeholder="Masukkan password"
                required
              />
            </div>
            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 text-red-500 text-sm bg-red-50 p-4 rounded-2xl border border-red-100"
              >
                <AlertCircle size={18} />
                <span>{error}</span>
              </motion.div>
            )}
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-5 rounded-2xl shadow-xl shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-70 active:scale-95"
            >
              {loading ? <Loader2 className="animate-spin" /> : "Masuk Sekarang"}
            </button>
          </form>
          
          <div className="mt-10 text-center">
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-[0.2em]">Created by Rindu IT</p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-28 font-sans max-w-md mx-auto relative shadow-2xl overflow-x-hidden">
      {/* Header */}
      <header className="bg-emerald-600 text-white p-8 rounded-b-[48px] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-400/20 rounded-full -ml-12 -mb-12 blur-xl" />
        
        <div className="flex justify-between items-center mb-8 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/30">
              <UserIcon size={24} />
            </div>
            <div>
              <p className="text-emerald-100 text-xs font-medium">Selamat bekerja,</p>
              <h2 className="text-xl font-bold tracking-tight">{user.name}</h2>
            </div>
          </div>
          <button 
            onClick={() => setUser(null)}
            className="p-3 bg-white/20 rounded-2xl hover:bg-white/30 transition-colors backdrop-blur-md border border-white/30"
          >
            <LogOut size={20} />
          </button>
        </div>
        
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-5 flex items-center gap-4 border border-white/20 relative z-10">
          <div className="p-3 bg-white/20 rounded-2xl">
            <MapPin size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] text-emerald-100 uppercase font-black tracking-widest mb-0.5">Lokasi Presensi</p>
            <p className="text-sm font-bold truncate">
              {location ? `${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}` : "Mencari koordinat GPS..."}
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 -mt-6 relative z-20">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Attendance Actions */}
              <section className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => startCamera('attendance')}
                  className="col-span-2 bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 flex flex-col items-center gap-4 hover:bg-slate-50 transition-all active:scale-95"
                >
                  {capturedPhoto ? (
                    <div className="relative w-full">
                      <img src={capturedPhoto} className="w-full h-48 object-cover rounded-2xl shadow-md" alt="Selfie" />
                      <div className="absolute top-3 right-3 bg-emerald-500 text-white p-1.5 rounded-full shadow-lg">
                        <CheckCircle2 size={16} />
                      </div>
                    </div>
                  ) : (
                    <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                      <Camera size={40} />
                    </div>
                  )}
                  <div className="text-center">
                    <span className="font-bold text-slate-800 block">{capturedPhoto ? "Ganti Foto Selfie" : "Ambil Foto Selfie"}</span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 block">Wajib untuk absensi</span>
                  </div>
                </button>

                <button 
                  onClick={() => handleAttendance('check-in')}
                  disabled={loading || !capturedPhoto}
                  className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 flex flex-col items-center gap-3 hover:bg-emerald-50 transition-all disabled:opacity-50 active:scale-95 group"
                >
                  <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:scale-110 transition-transform">
                    <Clock size={28} />
                  </div>
                  <span className="font-bold text-slate-800">Check In</span>
                </button>

                <button 
                  onClick={() => handleAttendance('check-out')}
                  disabled={loading || !capturedPhoto}
                  className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 flex flex-col items-center gap-3 hover:bg-red-50 transition-all disabled:opacity-50 active:scale-95 group"
                >
                  <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center text-red-600 group-hover:scale-110 transition-transform">
                    <LogOut size={28} />
                  </div>
                  <span className="font-bold text-slate-800">Check Out</span>
                </button>
              </section>

              {/* Visit Section */}
              <section className="bg-white p-7 rounded-[32px] shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-100 rounded-xl text-emerald-600">
                      <Store size={20} />
                    </div>
                    <h3 className="font-bold text-slate-800">Kunjungan Toko</h3>
                  </div>
                  {activeVisit && (
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse">
                      <div className="w-1.5 h-1.5 bg-white rounded-full" />
                      Aktif
                    </div>
                  )}
                </div>

                {activeVisit ? (
                  <div className="space-y-5">
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/5 rounded-full -mr-10 -mt-10" />
                      <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest mb-1">Lokasi Kunjungan</p>
                      <p className="text-lg font-bold text-slate-800 mb-1">{activeVisit.store_name}</p>
                      <div className="flex items-center gap-2 text-slate-400 text-xs">
                        <Clock size={12} />
                        <span>Mulai: {new Date(activeVisit.start_time).toLocaleTimeString()}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        const notes = prompt("Catatan kunjungan:");
                        if (notes !== null) handleEndVisit(notes);
                      }}
                      className="w-full bg-slate-900 text-white font-bold py-5 rounded-2xl shadow-xl shadow-slate-900/20 transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 size={20} />
                      Selesaikan Kunjungan
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="Nama Toko / Outlet"
                        className="w-full px-5 py-5 rounded-2xl bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all pr-12"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleStartVisit((e.target as HTMLInputElement).value);
                        }}
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300">
                        <Plus size={24} />
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-400 text-center font-bold uppercase tracking-widest">Tekan Enter untuk mulai kunjungan</p>
                  </div>
                )}
              </section>
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div 
              key="reports"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 text-xl tracking-tight">Laporan Display</h3>
                <div className="p-2 bg-emerald-100 rounded-xl text-emerald-600">
                  <FileText size={20} />
                </div>
              </div>

              {/* Create Report Form */}
              <section className="bg-white p-7 rounded-[32px] shadow-sm border border-slate-100 space-y-5">
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => startCamera('report_before')}
                    className="aspect-square bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-2 overflow-hidden group hover:border-emerald-300 transition-colors"
                  >
                    {reportPhotos.before ? (
                      <img src={reportPhotos.before} className="w-full h-full object-cover" alt="Before" />
                    ) : (
                      <>
                        <ImageIcon size={20} className="text-slate-400 group-hover:text-emerald-500" />
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Foto Before</span>
                      </>
                    )}
                  </button>

                  <button 
                    onClick={() => startCamera('report_after')}
                    className="aspect-square bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-2 overflow-hidden group hover:border-emerald-300 transition-colors"
                  >
                    {reportPhotos.after ? (
                      <img src={reportPhotos.after} className="w-full h-full object-cover" alt="After" />
                    ) : (
                      <>
                        <ImageIcon size={20} className="text-slate-400 group-hover:text-emerald-500" />
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Foto After</span>
                      </>
                    )}
                  </button>

                  <button 
                    onClick={() => startCamera('report_promo')}
                    className="aspect-square bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-2 overflow-hidden group hover:border-emerald-300 transition-colors"
                  >
                    {reportPhotos.promo ? (
                      <img src={reportPhotos.promo} className="w-full h-full object-cover" alt="Promo" />
                    ) : (
                      <>
                        <ImageIcon size={20} className="text-slate-400 group-hover:text-emerald-500" />
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Foto Promo</span>
                      </>
                    )}
                  </button>

                  <button 
                    onClick={() => startCamera('report_extra')}
                    className="aspect-square bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-2 overflow-hidden group hover:border-emerald-300 transition-colors"
                  >
                    {reportPhotos.extra ? (
                      <img src={reportPhotos.extra} className="w-full h-full object-cover" alt="Extra" />
                    ) : (
                      <>
                        <ImageIcon size={20} className="text-slate-400 group-hover:text-emerald-500" />
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Extra Display</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="space-y-4">
                  <input 
                    type="text" 
                    placeholder="Nama Toko"
                    value={reportStore}
                    onChange={(e) => setReportStore(e.target.value)}
                    className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:border-emerald-500 outline-none transition-all"
                  />
                  <textarea 
                    placeholder="Deskripsi laporan (stok, display, dll)"
                    value={reportDesc}
                    onChange={(e) => setReportDesc(e.target.value)}
                    rows={3}
                    className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:border-emerald-500 outline-none transition-all resize-none"
                  />
                  <button 
                    onClick={handleCreateReport}
                    disabled={loading || !reportPhotos.before || !reportPhotos.after}
                    className="w-full bg-emerald-600 text-white font-bold py-5 rounded-2xl shadow-xl shadow-emerald-600/20 flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 transition-all"
                  >
                    <Send size={20} />
                    Kirim Laporan
                  </button>
                </div>
              </section>

              {/* Report History */}
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Laporan Terbaru</h4>
                {reportHistory.map((report) => (
                  <div key={report.id} className="bg-white p-5 rounded-[32px] shadow-sm border border-slate-100 space-y-4">
                    <div className="flex items-center justify-between">
                      <p className="font-bold text-slate-800 truncate">{report.store_name}</p>
                      <p className="text-[10px] text-slate-300 font-bold uppercase">{new Date(report.timestamp).toLocaleDateString()}</p>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2">
                      <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-100 relative group">
                        <img src={report.photo_before} className="w-full h-full object-cover" alt="Before" />
                        <span className="absolute bottom-1 left-1 bg-black/50 text-white text-[6px] px-1 rounded uppercase font-bold">Before</span>
                      </div>
                      <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-100 relative group">
                        <img src={report.photo_after} className="w-full h-full object-cover" alt="After" />
                        <span className="absolute bottom-1 left-1 bg-black/50 text-white text-[6px] px-1 rounded uppercase font-bold">After</span>
                      </div>
                      {report.photo_promo && (
                        <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-100 relative group">
                          <img src={report.photo_promo} className="w-full h-full object-cover" alt="Promo" />
                          <span className="absolute bottom-1 left-1 bg-black/50 text-white text-[6px] px-1 rounded uppercase font-bold">Promo</span>
                        </div>
                      )}
                      {report.photo_extra && (
                        <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-100 relative group">
                          <img src={report.photo_extra} className="w-full h-full object-cover" alt="Extra" />
                          <span className="absolute bottom-1 left-1 bg-black/50 text-white text-[6px] px-1 rounded uppercase font-bold">Extra</span>
                        </div>
                      )}
                    </div>
                    
                    <p className="text-xs text-slate-500 line-clamp-2">{report.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div 
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <h3 className="font-bold text-slate-800 text-xl tracking-tight">Riwayat Aktivitas</h3>
              
              <div className="space-y-4">
                {attendanceHistory.map((item) => (
                  <div key={item.id} className="bg-white p-5 rounded-[32px] shadow-sm border border-slate-100 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${item.type === 'check-in' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'}`}>
                        {item.type === 'check-in' ? <CheckCircle2 size={24} /> : <LogOut size={24} />}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 capitalize">{item.type.replace('-', ' ')}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{new Date(item.timestamp).toLocaleString()}</p>
                      </div>
                    </div>
                    {item.photo_url && (
                      <div className="relative group-hover:scale-110 transition-transform">
                        <img src={item.photo_url} className="w-14 h-14 rounded-2xl object-cover shadow-sm border-2 border-white" alt="Proof" />
                      </div>
                    )}
                  </div>
                ))}

                {attendanceHistory.length === 0 && (
                  <div className="text-center py-20 text-slate-300">
                    <History size={64} className="mx-auto mb-4 opacity-10" />
                    <p className="font-bold uppercase tracking-widest text-xs">Belum ada riwayat</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'profile' && (
            <motion.div 
              key="profile"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6"
            >
              <div className="bg-white p-10 rounded-[48px] shadow-sm border border-slate-100 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500" />
                <div className="w-28 h-28 bg-emerald-50 rounded-full mx-auto flex items-center justify-center text-emerald-600 mb-6 border-4 border-white shadow-lg">
                  <UserIcon size={56} />
                </div>
                <h3 className="text-2xl font-bold text-slate-800 tracking-tight">{user.name}</h3>
                <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-[10px] mt-1">{user.role}</p>
                
                <div className="mt-10 pt-10 border-t border-slate-50 grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-xl font-black text-emerald-600">{attendanceHistory.length}</p>
                    <p className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Hadir</p>
                  </div>
                  <div className="text-center border-x border-slate-50">
                    <p className="text-xl font-black text-emerald-600">{visitHistory.length}</p>
                    <p className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Visit</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-black text-emerald-600">{reportHistory.length}</p>
                    <p className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Report</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <button className="w-full bg-white p-5 rounded-3xl flex items-center justify-between text-slate-700 font-bold group hover:bg-slate-50 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:text-emerald-500 transition-colors">
                      <UserIcon size={20} />
                    </div>
                    <span>Pengaturan Akun</span>
                  </div>
                  <ChevronRight size={20} className="text-slate-300" />
                </button>
                <button className="w-full bg-white p-5 rounded-3xl flex items-center justify-between text-slate-700 font-bold group hover:bg-slate-50 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:text-emerald-500 transition-colors">
                      <AlertCircle size={20} />
                    </div>
                    <span>Bantuan & Dukungan</span>
                  </div>
                  <ChevronRight size={20} className="text-slate-300" />
                </button>
                <button 
                  onClick={() => setUser(null)}
                  className="w-full bg-red-50 p-6 rounded-3xl flex items-center justify-between text-red-600 font-black uppercase tracking-widest text-xs mt-6 shadow-lg shadow-red-600/5 active:scale-95 transition-all"
                >
                  <span>Keluar Aplikasi</span>
                  <LogOut size={20} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Camera Modal */}
      {showCamera && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-8">
          <div className="relative w-full max-w-sm aspect-[3/4] rounded-[40px] overflow-hidden border-4 border-white/20 shadow-2xl">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute inset-0 border-[40px] border-black/20 pointer-events-none" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-dashed border-white/40 rounded-full pointer-events-none" />
          </div>
          <canvas ref={canvasRef} className="hidden" />
          
          <div className="mt-16 flex items-center gap-10">
            <button 
              onClick={() => {
                const stream = videoRef.current?.srcObject as MediaStream;
                stream?.getTracks().forEach(t => t.stop());
                setShowCamera(false);
              }}
              className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center text-white backdrop-blur-xl border border-white/20 active:scale-90 transition-transform"
            >
              <AlertCircle size={32} />
            </button>
            <button 
              onClick={capturePhoto}
              className="w-24 h-24 bg-white rounded-full flex items-center justify-center text-emerald-600 shadow-2xl shadow-emerald-500/40 active:scale-75 transition-all p-2"
            >
              <div className="w-full h-full border-4 border-emerald-600 rounded-full flex items-center justify-center">
                <div className="w-14 h-14 bg-emerald-600 rounded-full" />
              </div>
            </button>
            <div className="w-16" /> {/* Spacer */}
          </div>
          <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] mt-10 text-center">
            {cameraPurpose === 'attendance' ? "Posisikan wajah di tengah" : 
             cameraPurpose === 'report_before' ? "Foto Before (Kerapihan)" :
             cameraPurpose === 'report_after' ? "Foto After (Kerapihan)" :
             cameraPurpose === 'report_promo' ? "Foto Implementasi Promo" :
             "Foto Ekstra Display"}
          </p>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-2xl border-t border-slate-100 px-8 py-5 flex justify-between items-center z-40 rounded-t-[40px] shadow-[0_-20px_40px_rgba(0,0,0,0.05)]">
        <button 
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'home' ? 'text-emerald-600 scale-110' : 'text-slate-300 hover:text-slate-400'}`}
        >
          <Home size={24} strokeWidth={activeTab === 'home' ? 2.5 : 2} />
          <span className="text-[9px] font-black uppercase tracking-widest">Home</span>
        </button>
        <button 
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'reports' ? 'text-emerald-600 scale-110' : 'text-slate-300 hover:text-slate-400'}`}
        >
          <FileText size={24} strokeWidth={activeTab === 'reports' ? 2.5 : 2} />
          <span className="text-[9px] font-black uppercase tracking-widest">Report</span>
        </button>
        <button 
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'history' ? 'text-emerald-600 scale-110' : 'text-slate-300 hover:text-slate-400'}`}
        >
          <History size={24} strokeWidth={activeTab === 'history' ? 2.5 : 2} />
          <span className="text-[9px] font-black uppercase tracking-widest">History</span>
        </button>
        <button 
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'profile' ? 'text-emerald-600 scale-110' : 'text-slate-300 hover:text-slate-400'}`}
        >
          <UserIcon size={24} strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
          <span className="text-[9px] font-black uppercase tracking-widest">Profile</span>
        </button>
      </nav>
    </div>
  );
}
