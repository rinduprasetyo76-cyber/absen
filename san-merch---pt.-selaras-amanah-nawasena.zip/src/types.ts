export interface User {
  id: number;
  username: string;
  name: string;
  role: 'admin' | 'merchandiser';
}

export interface Attendance {
  id: number;
  user_id: number;
  type: 'check-in' | 'check-out';
  timestamp: string;
  latitude: number;
  longitude: number;
  photo_url?: string;
}

export interface Visit {
  id: number;
  user_id: number;
  store_name: string;
  start_time: string;
  end_time?: string;
  latitude: number;
  longitude: number;
  notes?: string;
}

export interface Report {
  id: number;
  user_id: number;
  store_name: string;
  photo_before: string;
  photo_after: string;
  photo_promo: string;
  photo_extra: string;
  description: string;
  timestamp: string;
}
