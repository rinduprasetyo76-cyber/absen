import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("attendance.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    name TEXT,
    role TEXT DEFAULT 'merchandiser'
  );

  CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    type TEXT, -- 'check-in', 'check-out'
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    latitude REAL,
    longitude REAL,
    photo_url TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    store_name TEXT,
    start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    end_time DATETIME,
    latitude REAL,
    longitude REAL,
    notes TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    store_name TEXT,
    photo_before TEXT,
    photo_after TEXT,
    photo_promo TEXT,
    photo_extra TEXT,
    description TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Migration for existing reports table
try {
  db.prepare("ALTER TABLE reports ADD COLUMN photo_before TEXT").run();
  db.prepare("ALTER TABLE reports ADD COLUMN photo_after TEXT").run();
  db.prepare("ALTER TABLE reports ADD COLUMN photo_promo TEXT").run();
  db.prepare("ALTER TABLE reports ADD COLUMN photo_extra TEXT").run();
} catch (e) {
  // Columns likely already exist
}

// Insert default user if not exists
const checkUser = db.prepare("SELECT * FROM users WHERE username = ?").get("admin");
if (!checkUser) {
  db.prepare("INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)").run(
    "admin",
    "admin123",
    "Administrator",
    "admin"
  );
  db.prepare("INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)").run(
    "merch1",
    "merch123",
    "Rindu Merchandiser",
    "merchandiser"
  );
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare("SELECT id, username, name, role FROM users WHERE username = ? AND password = ?").get(username, password);
    if (user) {
      res.json({ success: true, user });
    } else {
      res.status(401).json({ success: false, message: "Invalid credentials" });
    }
  });

  app.post("/api/attendance", (req, res) => {
    const { user_id, type, latitude, longitude, photo_url } = req.body;
    const result = db.prepare("INSERT INTO attendance (user_id, type, latitude, longitude, photo_url) VALUES (?, ?, ?, ?, ?)").run(
      user_id,
      type,
      latitude,
      longitude,
      photo_url
    );
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.get("/api/attendance/:user_id", (req, res) => {
    const { user_id } = req.params;
    const history = db.prepare("SELECT * FROM attendance WHERE user_id = ? ORDER BY timestamp DESC LIMIT 10").all(user_id);
    res.json(history);
  });

  app.post("/api/visits/start", (req, res) => {
    const { user_id, store_name, latitude, longitude } = req.body;
    const result = db.prepare("INSERT INTO visits (user_id, store_name, latitude, longitude) VALUES (?, ?, ?, ?)").run(
      user_id,
      store_name,
      latitude,
      longitude
    );
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.post("/api/visits/end", (req, res) => {
    const { visit_id, notes } = req.body;
    db.prepare("UPDATE visits SET end_time = CURRENT_TIMESTAMP, notes = ? WHERE id = ?").run(notes, visit_id);
    res.json({ success: true });
  });

  app.get("/api/visits/:user_id", (req, res) => {
    const { user_id } = req.params;
    const history = db.prepare("SELECT * FROM visits WHERE user_id = ? ORDER BY start_time DESC LIMIT 10").all(user_id);
    res.json(history);
  });

  app.post("/api/reports", (req, res) => {
    const { user_id, store_name, photo_before, photo_after, photo_promo, photo_extra, description } = req.body;
    const result = db.prepare("INSERT INTO reports (user_id, store_name, photo_before, photo_after, photo_promo, photo_extra, description) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      user_id,
      store_name,
      photo_before,
      photo_after,
      photo_promo,
      photo_extra,
      description
    );
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.get("/api/reports/:user_id", (req, res) => {
    const { user_id } = req.params;
    const reports = db.prepare("SELECT * FROM reports WHERE user_id = ? ORDER BY timestamp DESC LIMIT 10").all(user_id);
    res.json(reports);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
