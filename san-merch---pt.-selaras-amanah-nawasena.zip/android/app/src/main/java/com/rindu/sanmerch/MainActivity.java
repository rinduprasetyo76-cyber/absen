package com.rindu.sanmerch;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
